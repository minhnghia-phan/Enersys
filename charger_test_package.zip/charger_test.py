#!/usr/bin/env python3
import can, yaml, time, signal, threading, logging, csv
from pathlib import Path
from logging.handlers import TimedRotatingFileHandler

PROFILE_1K='1k'
PROFILE_1K5='1k5'

START_MSG={
 '1k': (0x901,[0x01,0x10,0x0e,0x68,0x01,0x64,0x00,0x18]),
 '1k5':(0x901,[0x01,0x10,0x0e,0x26,0x02,0x64,0x00,0x18])}
STOP_MSG=(0x901,[0,0,0,0,0,0,0,0])
CLEAR_MSG=(0x901,[0x02,0,0,0,0,0,0,0])
MUTE_MSG=(0x4000,[0x01,0,0,0,0,0,0,0])

running=True
reload_cfg=False
phase='OFF'

class Channel:
    def __init__(self,name,cfg,eventlog):
        self.name=name; self.cfg=cfg; self.profile=None; self.bus=None
        self.last_rx=time.time(); self.fault_retries=0; self.ready=False
        self.eventlog=eventlog
        self.csvf=open(Path(cfg['logging']['log_dir'])/f'{name}.csv','a',newline='')
        self.csv=csv.writer(self.csvf)

    def log_frame(self,d,msg):
        self.csv.writerow([time.strftime('%F %T'),self.name,d,hex(msg.arbitration_id),msg.dlc,' '.join(f'{b:02X}' for b in msg.data)])
        self.csvf.flush()

    def connect(self):
        try:
            self.bus=can.interface.Bus(channel=self.name,interface='socketcan')
            self.eventlog.info(f'{self.name} connected')
            self.send(MUTE_MSG); time.sleep(0.2); self.send(CLEAR_MSG)
            return True
        except Exception as e:
            self.eventlog.error(f'{self.name} connect failed {e}')
            return False

    def send(self,frame):
        if not self.bus:return
        mid,data=frame
        m=can.Message(arbitration_id=mid,data=data,is_extended_id=True)
        self.bus.send(m)
        self.log_frame('TX',m)

cfg=yaml.safe_load(open('config.yaml'))
Path(cfg['logging']['log_dir']).mkdir(exist_ok=True)
logger=logging.getLogger('events'); logger.setLevel(logging.INFO)
fh=TimedRotatingFileHandler(Path(cfg['logging']['log_dir'])/'events.log',when='midnight')
logger.addHandler(fh)
chs=[Channel(n,cfg,logger) for n in cfg['interfaces'].keys()]
for c in chs: c.connect()

def rx_thread(ch):
    while running:
        try:
            if ch.bus is None:
                ch.connect(); time.sleep(2); continue
            msg=ch.bus.recv(1.0)
            if not msg: continue
            ch.last_rx=time.time(); ch.log_frame('RX',msg)
            if msg.arbitration_id==0x81 and len(msg.data)>3:
                p=msg.data[3]
                new={0x11:'1k',0x14:'1k5'}.get(p)
                if new!=ch.profile:
                    logger.info(f'{ch.name} profile {ch.profile}->{new}')
                ch.profile=new
                ch.ready=new is not None
            if msg.arbitration_id==0x41 and len(msg.data)>=8:
                fault=any(b!=0 for b in msg.data[4:8])
                if fault:
                    logger.warning(f'{ch.name} fault')
        except Exception as e:
            logger.error(f'{ch.name} rx {e}')
            ch.bus=None

def scheduler():
    global phase
    while running:
        phase='ON'
        end=time.time()+cfg['timing']['on_time_s']
        while running and time.time()<end:
            for ch in chs:
                if not ch.ready: continue
                ch.send(MUTE_MSG); time.sleep(cfg['timing']['mute_delay_s'])
                ch.send(START_MSG[ch.profile])
            time.sleep(cfg['can']['tx_period_s'])
        phase='OFF'
        end=time.time()+cfg['timing']['off_time_s']
        while running and time.time()<end:
            for ch in chs:
                if not ch.ready: continue
                ch.send(MUTE_MSG); time.sleep(cfg['timing']['mute_delay_s'])
                ch.send(STOP_MSG)
            time.sleep(cfg['can']['tx_period_s'])

def sigterm(a,b):
    global running
    running=False
    for ch in chs:
        try: ch.send(STOP_MSG)
        except: pass

signal.signal(signal.SIGTERM,sigterm)
signal.signal(signal.SIGINT,sigterm)
for c in chs:
    threading.Thread(target=rx_thread,args=(c,),daemon=True).start()
threading.Thread(target=scheduler,daemon=True).start()
while running: time.sleep(1)
