Charger endurance test framework skeleton.

Install:
1. sudo apt install python3-can python3-yaml
2. Copy files to /opt/charger-test
3. Adjust config.yaml
4. sudo cp charger-test.service /etc/systemd/system/
5. sudo systemctl daemon-reload
6. sudo systemctl enable --now charger-test

Logs are stored in ./logs

NOTE: This is a starter implementation. Add your serial-number-based udev mapping and SocketCAN recovery routines before production use.
